 <?php
  // Panggil koneksi database
  require_once "config/database.php";

  if (isset($_GET['nim'])) {
    try {
      // sql statement untuk menampilkan data dari tabel marketer berdasarkan nim
      $query = "SELECT * FROM kavling WHERE nim=:nim";
      // membuat prepared statements
      $stmt = $pdo->prepare($query);

      //mengikat parameter 
      $stmt->bindParam(':nim', $_GET['nim']);

      // eksekusi query
      $stmt->execute();

      // mengambil data mahasiswa
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      // nilai untuk mengisi form
      $nim           = $data['nim'];
      $kav           = $data['no_kav'];
      $tanah         = $data['l_tanah'];
      $bangunan      = $data['l_bangunan'];
      $tipe          = $data['tipe'];
      $posisi        = $data['posisi'];
      $harga        = $data['harga'];
      $ppn       = $data['ppn'];
      $total         = $data['total'];
      $cara_bayar         = $data['cara_bayar'];
      $pelunasan          = $data['pelunasan'];
      $utj          = $data['utj'];
      $dp          = $data['dp'];
      

      // tutup koneksi database
      $pdo = null;
    } catch (PDOException $e) {
      // tampilkan pesan kesalahan
      echo "ada kesalahan pada query : ".$e->getMessage();
    }
  }
  ?>
  
  <script type="text/javascript">
    $(function () {
      //datepicker plugin
      $('.date-picker').datepicker({
        autoclose: true,
        todayHighlight: true
      });
    })
  </script>

  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">
          <i class="glyphicon glyphicon-edit"></i> 
          Ubah data Pelanggan
        </h4>
      </div>

      <div class="modal-body">
        <form action="proses-ubah.php" method="POST" name="modal_popup" enctype="multipart/form-data" >
          <div class="form-group">
            <label>Kode</label>
            <input type="text" class="form-control" name="nim" value="<?php echo $nim; ?>" readonly required/>
          </div>

          <div class="form-group">
            <label>Nomor Kavling</label>
            <input type="text" class="form-control" name="no_kav" autocomplete="off" value="<?php echo $kav; ?>" required/>
          </div>

          <div class="form-group">
            <label>Luas Tanah</label>
            <input type="text" class="form-control" name="l_tanah" autocomplete="off" value="<?php echo $tanah; ?>" required/>
          </div>

          <div class="form-group">
            <label>Luas Bangunan</label>
            <input type="text" class="form-control" name="l_bangunan" autocomplete="off" value="<?php echo $bangunan; ?>" required/>
          </div>

          <div class="form-group">
            <label>Tipe</label>
            <input type="text" class="form-control" name="tipe" autocomplete="off" value="<?php echo $tipe; ?>" required/>
          </div>

          <div class="form-group">
            <label>Posisi</label>
            <input type="text" class="form-control" name="posisi" autocomplete="off" value="<?php echo $posisi; ?>" required/>
          </div>

          <div class="form-group">
            <label>Harga</label>
            <input type="text" class="form-control" name="harga" autocomplete="off" value="<?php echo $harga; ?>" required/>
          </div>

          <div class="form-group">
            <label>PPN</label>
            <input type="text" class="form-control" name="ppn" autocomplete="off" value="<?php echo $ppn; ?>" required/>
          </div>

          <div class="form-group">
            <label>Total</label>
            <input type="text" class="form-control" name="total" autocomplete="off" value="<?php echo $total; ?>" required/>
          </div>

          <div class="form-group">
            <label>Cara Bayar</label>
            <input type="text" class="form-control" name="cara_bayar" autocomplete="off" value="<?php echo $cara_bayar; ?>" required/>
          </div>

          <div class="form-group">
            <label>Pelunasan</label>
            <input type="text" class="form-control" name="pelunasan" autocomplete="off" value="<?php echo $pelunasan; ?>" required/>
          </div>

          <div class="form-group">
            <label>UTJ</label>
            <input type="text" class="form-control" name="utj" autocomplete="off" value="<?php echo $utj; ?>" required/>
          </div>

          <div class="form-group">
            <label>DP</label>
            <input type="text" class="form-control" name="dp" autocomplete="off" value="<?php echo $dp; ?>" required/>
          </div>

          <!-- <div class="form-group">
            <label>Telepon</label>
            <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $telepon; ?>" required>
          </div> -->

        
           <!-- <div class="form-group">
            <label>Kota</label>
            <input type="text" class="form-control" name="kota1" autocomplete="off" value="<?php echo $kota1; ?>" required/>
          </div> -->
          
          <!-- <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" name="email" autocomplete="off" value="<?php echo $email; ?>" required/>
          </div> -->

          

          <div class="modal-footer">
            <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
            <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>