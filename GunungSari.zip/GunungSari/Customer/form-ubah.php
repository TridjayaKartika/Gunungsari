 <?php
  // Panggil koneksi database
  require_once "config/database.php";

  if (isset($_GET['nim'])) {
    try {
      // sql statement untuk menampilkan data dari tabel marketer berdasarkan nim
      $query = "SELECT * FROM customer WHERE nim=:nim";
      // membuat prepared statements
      $stmt = $pdo->prepare($query);

      //mengikat parameter 
      $stmt->bindParam(':nim', $_GET['nim']);

      // eksekusi query
      $stmt->execute();

      // mengambil data mahasiswa
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      // nilai untuk mengisi form
      $nim           = $data['nim'];
      $nama          = $data['nama'];
      // $tempat_lahir  = $data['tempat_lahir'];
      
      // $tanggal       = $data['tanggal_lahir'];
      // $tgl           = explode('-',$tanggal);
      // $tanggal_lahir = $tgl[2]."-".$tgl[1]."-".$tgl[0];
      
      // $jenis_kelamin = $data['jenis_kelamin'];
      $alamat        = $data['alamat'];
      $telepon       = $data['telepon'];
      // $kota1         = $data['kota1'];
      $email         = $data['email'];
      $foto          = $data['foto'];
      

      // tutup koneksi database
      $pdo = null;
    } catch (PDOException $e) {
      // tampilkan pesan kesalahan
      echo "ada kesalahan pada query : ".$e->getMessage();
    }
  }
  ?>
  
  <script type="text/javascript">
    $(function () {
      //datepicker plugin
      $('.date-picker').datepicker({
        autoclose: true,
        todayHighlight: true
      });
    })
  </script>

  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">
          <i class="glyphicon glyphicon-edit"></i> 
          Ubah data Pelanggan
        </h4>
      </div>

      <div class="modal-body">
        <form action="proses-ubah.php" method="POST" name="modal_popup" enctype="multipart/form-data" >
          <div class="form-group">
            <label>Kode</label>
            <input type="text" class="form-control" name="nim" value="<?php echo $nim; ?>" readonly required/>
          </div>

          <div class="form-group">
            <label>Nama Marketer</label>
            <input type="text" class="form-control" name="nama" autocomplete="off" value="<?php echo $nama; ?>" required/>
          </div>

          

          <div class="form-group">
            <label>Alamat</label>
            <textarea class="form-control" name="alamat" rows="3" required><?php echo $alamat; ?></textarea>
          </div>

          <div class="form-group">
            <label>Telepon</label>
            <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $telepon; ?>" required>
          </div>

        
           <!-- <div class="form-group">
            <label>Kota</label>
            <input type="text" class="form-control" name="kota1" autocomplete="off" value="<?php echo $kota1; ?>" required/>
          </div> -->
          
          <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" name="email" autocomplete="off" value="<?php echo $email; ?>" required/>
          </div>

          <div class="form-group">
            <label>KTP</label> <br>
            <?php  
            if ($foto=="") { ?>
              <img class="img-mahasiswa" src="foto/default_user.png" alt="Foto" width="110">
            <?php
            } else { ?>
              <img class="img-mahasiswa" src="foto/<?php echo $foto; ?>" alt="Foto" width="110">
            <?php
            }
            ?>
            <br><br>
            <input type="file" name="foto">
            <p class="help-block">
              <small>Catatan :</small> <br>
              <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
              <small>- Ukuran file foto max 1 Mb</small>
            </p>
          </div>

          <div class="modal-footer">
            <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
            <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>