<?php require_once 'config.php' ?>
<html>
<head>
	<title>Data Kavling</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
	

	<table class="table">
		
		<thead>
			<tr>
			<th>Kode</th>
			<th>No Kavling</th>
			<th>L Tanah</th>
			<th>L Bangunan</th>
			<th>Type</th>
			<th>Harga List</th>
			<th>Harga Launching</th>
			<th>Status</th>	
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		//$bulan	= array (1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
		while ($row = mysqli_fetch_array($query))
		{
			//$tgl 	= explode('-', $row['tanggal']);
			$harga_list  = $row['price_list'] == 0 ? '' : number_format($row['price_list'], 0, ',', '.');
			$harga_launching  = $row['price_launching'] == 0 ? '' : number_format($row['price_launching'], 0, ',', '.');

			echo '<tr>
					<td>'.$no.'</td>
					<td>'.$row['no_kavling'].'</td>
					<td>'.$row['luas_tanah'].'</td>
					<td>'.$row['luas_bangunan'].'</td>
					<td>'.$row['type_bangunan'].'</td>
					<td>'.$harga_list.'</td>
					<td>'.$harga_launching.'</td>
					<td>'.$row['status'].'</td>
					
				</tr>';
			//$total += $row['price_list'];
			$no++;
		}?>
		</tbody>
		<tfoot>
			<tr>
				
			</tr>
		</tfoot>
	</table>
</body>
</html>