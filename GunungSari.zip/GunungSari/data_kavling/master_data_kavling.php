<?php require_once 'config.php' ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Master Data Kavling</title>

     <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">
    <header>
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1>Master Data Kavling</h1>
                        <p>By : IT Depatement on Maret 2019</p>
                    </div>
                  </div>
                  
                    
    </header>

    <section>
    <div class="col-md-8">

    <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    Projek <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#"> Projek 1 </a></li>
                                    <li><a href="#"> Projek 2 </a></li>
                                    <li><a href="#"> Projek 3 </a></li>
                                    <li class="devider"></li>
                                    <li><a href="#"> Menu 4 </a></li>
                                </ul>
                        </div>
                        <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    Kavling <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#"> Menu 1 </a></li>
                                    <li><a href="#"> Menu 2 </a></li>
                                    <li><a href="#"> Menu 3 </a></li>
                                    <li class="devider"></li>
                                    <li><a href="#"> Menu 4 </a></li>
                                </ul>
                        </div>
                        <a href="#" class="btn btn-secondary">Tambah</a>
                        <a href="#" class="btn btn-secondary">Edit</a>
                        <a href="#" class="btn btn-secondary">Hapus</a>
                        <a href="#" class="btn btn-secondary">Refresh</a>
                        <a href="#" class="btn btn-secondary">Preview</a>                        
                        <a href="#" class="btn btn-secondary">Excel</a>
                        
                    </div>
    <table class="table">
		
		<thead>
			<tr>
			<th>Kode</th>
			<th>No Kavling</th>
			<th>L Tanah</th>
			<th>L Bangunan</th>
			<th>Type</th>
			<th>Harga List</th>
			<th>Harga Launching</th>
			<th>Status</th>	
			</tr>
		</thead>
		<tbody>
		<?php
		$no 	= 1;
		$total 	= 0;
		//$bulan	= array (1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
		while ($row = mysqli_fetch_array($query))
		{
			//$tgl 	= explode('-', $row['tanggal']);
			$harga_list  = $row['price_list'] == 0 ? '' : number_format($row['price_list'], 0, ',', '.');
			$harga_launching  = $row['price_launching'] == 0 ? '' : number_format($row['price_launching'], 0, ',', '.');

			echo '<tr>
					<td>'.$no.'</td>
					<td>'.$row['no_kavling'].'</td>
					<td>'.$row['luas_tanah'].'</td>
					<td>'.$row['luas_bangunan'].'</td>
					<td>'.$row['type_bangunan'].'</td>
					<td>'.$harga_list.'</td>
					<td>'.$harga_launching.'</td>
					<td>'.$row['status'].'</td>
					
				</tr>';
			//$total += $row['price_list'];
			$no++;
		}?>
		</tbody>
		<tfoot>
			<tr>
				
			</tr>
		</tfoot>
	</table>
    
    
    
        

        <div class="container">
            
                <!-- <div class="row">
                    <div class="col-md-12">
                        <img class="img img-responsive" src="img/logodpn.png" />
                    </div>
                </div> -->
            </div>
    </section>

     <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>
