<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	if (isset($_POST['id_user'])) {
		// ambil data hasil submit dari form
		$id_user        = trim($_POST['id_user']);
		$nama           = trim($_POST['nama']);
		$username       = trim($_POST['username']);
		$password       = trim($_POST['password']);
		$level       	= trim($_POST['level_user']);
		$agen			= trim($_POST['agen_marketing']);
		$email			= trim($_POST['email']);
		$telepon		= trim($_POST['telp']);
		
		// $tanggal            = trim($_POST['tanggal_lahir']);
		// $tgl                = explode('-',$tanggal);
		// $tanggal_lahir      = $tgl[2]."-".$tgl[1]."-".$tgl[0];
		$nama_file          = $_FILES['foto']['name'];
		$ukuran_file        = $_FILES['foto']['size'];
		$tipe_file          = $_FILES['foto']['type'];
		$tmp_file           = $_FILES['foto']['tmp_name'];
		
		// $telepon            = trim($_POST['telepon']);
		// $kota1            	= trim($_POST['kota1']);
		// $email            	= trim($_POST['email']);
		
		
		
		// tentukan extension yang diperbolehkan
		$allowed_extensions = array('jpg','jpeg','png');
		
		// Set path folder tempat menyimpan gambarnya
		$path_file          = "foto/".$nama_file;
		
		// check extension
		$file               = explode(".", $nama_file);
		$extension          = array_pop($file);

		try {
			// jika foto diubah
			if (empty($_FILES['foto']['name'])) {
				// sql statement untuk mengubah data pada tabel marketer
		        $query = "UPDATE users SET  id_user 		= :id_user,
											foto			= :foto,
											nama 			= :nama,
											username 		= :username,
											password 		= :password,
											agen_marketing	= :agen_marketing,
											email			= :email,
											telp			= :telp
											level_user 		= :level_user,												  					  
											WHERE id_user 			= :id_user";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);
				$password = md5($password);
		        // mengikat parameter
				$stmt->bindParam(':id_user', $id_user);
				$stmt->bindParam(':nama', $nama);
				$stmt->bindParam(':username', $username);
				$stmt->bindParam(':password', $pass);
				$stmt->bindParam(':level_user', $level);
				$stmt->bindParam(':agen_marketing', $agen);
				$stmt->bindParam(':email', $email);
				$stmt->bindParam(':telp', $telepon);
				$stmt->bindParam(':foto', $nama_file);
				
			}
			// jika foto tidak diubah
			else {
				// Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
				if (in_array($extension, $allowed_extensions)) {
	                // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan :
	                if($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
	                    // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
	                    // Proses upload
	                    if(move_uploaded_file($tmp_file, $path_file)) { // Cek apakah gambar berhasil diupload atau tidak
	                		// Jika gambar berhasil diupload, Lakukan : 
					        // sql statement untuk mengubah data pada tabel marketer
					        $query = "UPDATE users SET foto	= :foto,
											nama 			= :nama,
											username 		= :username,
											password 		= :password,
											agen_marketing	= :agen_marketing,
											email			= :email,
											telp			= :telp
											level_user 		= :level_user,												  					  
											WHERE id_user 			= :id_user";
					        // membuat prepared statements
					        $stmt = $pdo->prepare($query);
							$password = md5($password);
					        // mengikat parameter
							$stmt->bindParam(':id_user', $id_user);
							$stmt->bindParam(':nama', $nama);
							$stmt->bindParam(':username', $username);
							$stmt->bindParam(':password', $password);
							$stmt->bindParam(':level_user', $level);
							$stmt->bindParam(':agen_marketing', $agen);
							$stmt->bindParam(':email', $email);
							$stmt->bindParam(':telp', $telepon);
							$stmt->bindParam(':foto', $nama_file);

	                    } else {
	                        // Jika gambar gagal diupload, tampilkan pesan gagal upload
	                        header("location: index.php?alert=5");
	                    }
	                } else {
	                    // Jika ukuran file lebih dari 1MB, tampilkan pesan gagal upload
	                    header("location: index.php?alert=6");
	                }
	            } else {
	                // Jika tipe file yang diupload bukan jpg, jpeg, png, tampilkan pesan gagal upload
	                header("location: index.php?alert=7");
	            }
	        }

			// eksekusi query
	        $stmt->execute();

	        // jika berhasil tampilkan pesan berhasil update data
			header('location: index.php?alert=2');

			// tutup koneksi database
	        $pdo = null;
		} catch (PDOException $e) {
			// tampilkan pesan kesalahan
	        echo "ada kesalahan : ".$e->getMessage();
		}
	}
}				
?>