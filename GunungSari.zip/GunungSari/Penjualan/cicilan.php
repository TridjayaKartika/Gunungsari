

<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<h3>SLIP ORDER</h3>


<?php
//require_once "config/database.php";

if (isset($_GET['proses'])) {
    // ambil data hasil submit dari form
    $kode_pelanggan     = $_GET['nim'];
    $nama               = $_GET['nama'];
    $alamat             = $_GET['alamat'];
    $telepon            = $_GET['telepon'];

    $kode_proyek        = $_GET['nim1'];
    $nama_proyek        = $_GET['nama_proyek'];
    $no_kav             = $_GET['no_kav'];
    $lb                 = $_GET['l_bangunan'];
    $lt                 = $_GET['l_tanah'];
    $tipe               = $_GET['tipe'];

	$harga_jadi         = $_GET['total'];
	$dpp                = $_GET['harga'];
	$ppn                = $_GET['ppn'];
    $tanda_jadi         = $_GET['tanda_jadi'];
    $um                 = $_GET['um'];
	$angsuran           = $_GET['angsuran'];

    $sisa_bayar = $harga_jadi - $tanda_jadi;
    $view_sisa_bayar = "Rp.".number_format($sisa_bayar,0,',','.');
    $view_harga_jadi = "Rp.".number_format($harga_jadi,0,',','.');

    $uang_muka = ($um/100) * $sisa_bayar;
    $view_uang_muka = "Rp.".number_format($uang_muka,0,',','.');

    // echo"<table>
    
    //         <tr><td>Uang Muka </td> <td>$view_uang_muka</td></tr>
    //         </table>";

    $jum_angsuran = $sisa_bayar / $angsuran;
    $view_angsuran = "Rp.".number_format($jum_angsuran,0,',','.');

    // for ($i=1; $i<=$angsuran; $i++)
    // {
    // echo"<table>
    // <tr><td>Angsuran $i </td> <td>$view_angsuran</td></tr> 
   
    // </table>";
    // }

    //date_default_timezone_set(‘Asia/Jakarta’);// Set timezone
    //variabel ini bisa kita isi dengan tanggal statis misalnya, ‘2017-05-01"
    // $dari = '2011-05-02';// tanggal mulai
    // $sampai = '2011-07-02';// tanggal akhir

    // while (strtotime($dari) <= strtotime($sampai)) {
        
    //     $dari = mktime(0,0,0,date("m",strtotime($dari)), date("d",strtotime($dari))+28,date("Y",strtotime($dari)));
    //     $dari=date("Y-m-d", $dari);
    //     echo "$dari<br/>";
    // }
    
}


?>

<table>
    <thead>
      <tr>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="width:200px">Nama Pembeli</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Alamat</td>
        <td style="width:10px">:</td>
        <td><?php echo "$alamat" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Telepon</td>
        <td style="width:10px">:</td>
        <td><?php echo "$telepon" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Lokasi Perumahan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama_proyek" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Tanggal Penjualan</td>
        <td style="width:10px">:</td>
        <td><?php echo " " ?></td>
      </tr>
      <tr>
        <td style="width:200px">No Kavling</td>
        <td style="width:10px">:</td>
        <td><?php echo "$kode_proyek/$no_kav - $tipe" ?></td>
      </tr>
      <tr>
        <td style="width:200px">L Tanah / L Bangunan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$lt/$lb" ?></td>
      </tr>
      
    </tbody>
  </table>
<br>

  <h4>JADWAL PEMBAYARAN YANG DISETUJUI</h4>
         
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Jenis Pembayaran</th>
        <th>Jatuh Tempo</th>
        <th>Jumlah</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>UANG MUKA</td>
        <td>None</td>
        <td><?php echo "$view_uang_muka" ?></td>
      </tr>
      
      <tr>
      <td><?php 
      for ($i=1; $i<=$angsuran; $i++)
      {
      echo"<table>
      <tr><td>ANGSURAN $i </td> </tr> 
     
      </table>";
      } ?></td>
        <td>None</td>
        <td>
        <?php 
      for ($i=1; $i<=$angsuran; $i++)
      {
      echo"<table>
      <tr><td>$view_angsuran</td></tr> 
     
      </table>";
      } ?>
        </td>
      </tr>
      <tr>
        <td colspan="2"><strong>TOTAL</strong></td>
        <td><?php echo "$view_harga_jadi" ?></td>
      </tr>
    </tbody>
  </table>
</div>

</body>
</html>