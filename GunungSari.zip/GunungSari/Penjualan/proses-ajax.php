<?php
require_once "config/database.php";
$nim = $_GET['nim'];
$query = "SELECT * FROM customer WHERE nim='$nim'";
$stmt = $pdo->prepare($query);
$stmt->execute();
$customer = $stmt->fetch(PDO::FETCH_ASSOC);
$data = array(
            'nama'      =>  $customer['nama'],
            'alamat'   =>  $customer['alamat'],
            'telepon'    =>  $customer['telepon'],);
 echo json_encode($data);
?>