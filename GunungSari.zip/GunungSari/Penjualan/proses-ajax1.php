<?php
require_once "config/database.php";
$nim1 = $_GET['nim1'];
$query = "SELECT * FROM kavling WHERE nim1='$nim1'";
$stmt = $pdo->prepare($query);
$stmt->execute();
$customer = $stmt->fetch(PDO::FETCH_ASSOC);
$data = array(
            'no_kav'      =>  $customer['no_kav'],
            'l_bangunan'   =>  $customer['l_bangunan'],
            'l_tanah'    =>  $customer['l_tanah'],
            'tipe'    =>  $customer['tipe'],
            'total'    =>  $customer['total'],
            'harga'    =>  $customer['harga'],
            'ppn'    =>  $customer['ppn'],);

 echo json_encode($data);
?>