<?php

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "db_gunung_sari";

try {    
    //create PDO connection 
    $db = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
   
    // set error mode
   $dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
  
   // jalankan query
   $result = $dbh->query('SELECT * FROM tb_kavling');
  
   // tampilkan data
   while($row = $result->fetch()) {
     echo "$row[0] $row[1] $row[2] $row[3] $row[6] $row[7] $row[8] $row[9]";    
     echo "<br />";
   }
 
   // hapus koneksi
   $dbh = null;

} catch(PDOException $e) {
    //show error
    die("Terjadi masalah: " . $e->getMessage());
}