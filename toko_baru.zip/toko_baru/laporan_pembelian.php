<?php
	include 'index.php';
?>

<form style="margin:20px">
<a onClick="window.print()" target="_blank" class="btn btn-primary" role="button">
<span class="glyphicon glyphicon-print"></span> Print Laporan</a>
<table class='table table-striped table-bordered table-hover'>
		<tr>
            <th>No Faktur</th>
            <th>Tanggal</th>
			<th>Kode Pembelian</th>
            <th>Nama Supplier</th>
            <th>Harga</th>
            <th>Qty</th>
            <th>Total</th>
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT * FROM tb_laporan_pembelian';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['no_faktur']; ?></td>
			<td><?php echo $data['tanggal']; ?></td>
			<td><?php echo $data['kode_pembelian']; ?></td>
			<td><?php echo $data['nama_supplier'];?></td>
			<td><?php echo $data['harga'];?></td>
			<td><?php echo $data['quantity'];?></td>
			<td><?php echo $data['total'];?></td>
			
		</tr>
	<?php } ?>
</form>