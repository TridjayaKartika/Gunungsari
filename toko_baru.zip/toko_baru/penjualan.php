<?php
include 'index.php';
?>

<form style="margin:20px">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
<span class="glyphicon glyphicon-plus"></span> Tambah</button>

<button type="submit" class="btn btn-danger">
<span class="glyphicon glyphicon-remove"></span> Hapus</button>
</form>
 
<form style="margin:20px" method="POST" action="">
<!-- Page Content -->  
 <div class="table-responsive">
<table class='table table-striped table-bordered table-hover'>
		<tr>
            <th width="10%">Kode Penjualan</th>
            <th width="20%">Nama Barang</th>
            <th width="20">Nama Customer</th>		
            <th width="15%">Harga Jual</th>
			<th width="10%">Tanggal Penjualan</th>
            <th width="10%">Qty</th>
			<th width="10%">Satuan</th>
            
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT * FROM tb_penjualan';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_penjualan']; ?></td>
			<td><?php echo $data['nama_barang']; ?></td>
			<td><?php echo $data['nama_customer']; ?></td>
			<td><?php echo $data['harga_jual'];?></td>
			<td><?php echo $data['tanggal_penjualan'];?></td>
			<td><?php echo $data['quantity'];?></td>
			<td><?php echo $data['satuan'];?></td>
			
		</tr>
	<?php } ?>
	</table>
</div>



<!-- Modal Tambah -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Penjualan Barang</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
                                            	
			<div class="form-group">
             <label>Kode Penjualan</label>
              <input class="form-control" required autocomplete="off" name="kode_penjualan" maxlength="15">
            </div>
			<div class="form-group">
             <label>Nama Barang</label>
                <input class="form-control" required autocomplete="off" name="nama_barang" maxlength="15">
            </div>	
			<div class="form-group">
             <label>Nama Customer</label>
                <input class="form-control" required autocomplete="off" name="nama_customer" maxlength="15">
            </div>
			<label>Harga Jual</label>
                <input type="text" class="form-control" required autocomplete="off" name="harga_jual" maxlength="15"
				onkeydown="return numberonly(this, event);" onkeyup="javascript:tandaPemisahTitik(this);">
            
			</div>
			<div class="form-group">
			<label>Tanggal Penjualan</label>
                <input class="form-control" required autocomplete="off" name="tanggal_penjualan" maxlength="15">
            </div>
			<div class="form-group">
			<label>Qty</label>
                <input class="form-control" required autocomplete="off" name="quantity" maxlength="15">
            </div>
			<div class="form-group">
             <label>Satuan</label>
                <input class="form-control" required autocomplete="off" name="satuan" maxlength="15">
            </div>

			
                                        <button type="submit" class="btn btn-primary" name="btn_simpan">
										<span class="glyphicon glyphicon-save"></span> Simpan</button>
                                        <button type="reset" class="btn btn-danger" data-dismiss="modal">
										<span class="glyphicon glyphicon-remove"></span> Batal</button>
		
		<?php
		if (isset($_POST['btn_simpan'])){
			//$modal= $_POST['myModal'];
			$kode_penjualan = $_POST['kode_penjualan'];
			$nama_barang = $_POST['nama_barang'];
			$nama_customer = $_POST['nama_customer'];
			$harga_jual = $_POST['harga_jual'];
			$taggal_penjualan = $_POST['tanggal_penjualan'];
			$qty = $_POST['quantity'];
			$satuan = $_POST['satuan'];
			$total = $_POST['total'];
			//include_once("koneksi.php");
			mysqli_query($conn, "INSERT INTO tb_penjualan(kode_penjualan,nama_barang,nama_customer, harga_jual, tanggal_penjualan, quantity, satuan) VALUES('$kode_penjualan','$nama_barang','$nama_customer','$harga_jual','$tanggal_penjualan','$qty','$satuan')");
			
		}
	?>
	
	
      </div>

    </div>

  </div>
</form>