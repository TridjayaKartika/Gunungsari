<?php
	include 'index.php';
?>



<form style="margin:20px">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
<span class="glyphicon glyphicon-usd"></span> Proses Pembayaran</button>

<a href="print_pembayaran_hutang.php" target="_blank" class="btn btn-danger" role="button"> 
<span class="glyphicon glyphicon-print"></span> Print</button>
</a>
</form>

<form style="margin:20px" method="POST" action="">
<div class="table-responsive"> 
<table class="table table-striped table-bordered table-hover">
		<tr>
            <th>No Nota</th>
            <th>Tanggal</th>
			<th>Nama Customer</th>
            <th>Hutang</th>
			<th>Tunai</th>
		
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT * FROM tb_pembayaran_hutang';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_pem_hutang']; ?></td>
			<td><?php echo $data['tanggal_pembayaran']; ?></td>
			<td><?php echo $data['nama_customer']; ?></td>
			<td><?php echo $data['total_bayar'];?></td>
			<td><?php echo $data['tunai'];?></td>
		
			
		</tr>
	<?php } ?>
</table>
</div>

<!-- Modal Pembayaran Hutang -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Pembayaran Hutang</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
                                            	
			<div class="form-group">
             <label>Kode Pembayaran</label>
              <input class="form-control" required autocomplete="off" name="kode_pem_hutang" maxlength="15">
            </div>
			<div class="form-group">
             <label>Tanggal</label>
                <input class="form-control" required autocomplete="off" name="tanggal_pembayaran" maxlength="15">
            </div>	
			<div class="form-group">
             <label>Nama Customer</label>
                <input class="form-control" required autocomplete="off" name="nama_customer" maxlength="15">
            </div>
			<div class="form-group">
             <label>Total Hutang</label>
                <input class="form-control" required autocomplete="off" name="total_bayar" maxlength="15">
            </div>
			<div class="form-group">
             <label>Tunai</label>
                <input class="form-control" required autocomplete="off" name="tunai" maxlength="15">
            </div>
			
                                        <button type="submit" class="btn btn-primary"name="btn_simpan">
										<span class="glyphicon glyphicon-save"></span> Simpan</button>
                                        <button type="reset" class="btn btn-danger" data-dismiss="modal">
										<span class="glyphicon glyphicon-remove"></span> Batal</button>
      <?php
		if (isset($_POST['btn_simpan'])){
			//$modal= $_POST['myModal'];
			$kode_pem_hutang = $_POST['kode_pem_hutang'];
			$tanggal_pembayaran = $_POST['tanggal_pembayaran'];
			$nama_customer = $_POST['nama_customer'];
			$total_bayar = $_POST['total_bayar'];
			$tunai = $_POST['tunai'];
			

			//include_once("koneksi.php");
			mysqli_query($conn, "INSERT INTO tb_pembayaran_hutang(kode_pem_hutang,tanggal_pembayaran,nama_customer,total_bayar,tunai) VALUES('$kode_pem_hutang','$tanggal_pembayaran','$nama_customer','$tunai')");
			
		}
	?>
	  </div>

    </div>

  </div>
</form>
</form>