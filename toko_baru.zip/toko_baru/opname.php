<?php
include 'index.php';
?>
<form class="form-inline" action="/action_page.php" style="margin:20px">
  
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    <span class="glyphicon glyphicon-plus"></span> Tambah
  </button>
</p>
</form>

<form style="margin:20px" method="POST" action="">
<table class='table table-striped table-bordered table-hover'>
		<tr>
            <th width="10%">No</th>
            <th width="30%">Nama Barang</th>
            <th width="20%">Jumlah (Kg)</th>
            <th width="25%">Pilihan (Masuk / Keluar)</th>
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT * FROM tb_opname';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['no']; ?></td>
			<td><?php echo $data['nama_barang']; ?></td>
			<td><?php echo $data['jumlah']; ?></td>
			<td><?php echo $data['pilihan'];?></td>
					
			
		</tr>
	<?php } ?>
	</table>
	
	<!-- Modal Pembayaran Hutang -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Transaksi</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
                                            	
			<div class="form-group">
             <label>No</label>
              <input class="form-control" required autocomplete="off" name="no" maxlength="15">
            </div>
			<div class="form-group">
             <label>Nama Barang</label>
                <input class="form-control" required autocomplete="off" name="nama_barang" maxlength="15">
            </div>	
			<div class="form-group">
             <label>Jumlah (Kg)</label>
                <input class="form-control" required autocomplete="off" name="jumlah" maxlength="15">
            </div>
			<div class="form-group">
             <label>Pilihan (Masuk/Keluar)</label>
                <input class="form-control" required autocomplete="off" name="pilihan" maxlength="15">
            </div>
			
			
                                        <button type="submit" class="btn btn-primary"name="btn_simpan">
										<span class="glyphicon glyphicon-save"></span> Simpan</button>
                                        <button type="reset" class="btn btn-danger" data-dismiss="modal">
										<span class="glyphicon glyphicon-remove"></span> Batal</button>
      <?php
		if (isset($_POST['btn_simpan'])){
			//$modal= $_POST['myModal'];
			$no = $_POST['no'];
			$nama_barang = $_POST['nama_barang'];
			$jumlah = $_POST['jumlah'];
			$pilihan = $_POST['pilihan'];

			//include_once("koneksi.php");
			mysqli_query($conn, "INSERT INTO tb_opname(no,nama_barang,jumlah,pilihan) VALUES('$no','$nama_barang','$jumlah','$pilihan')");
			
		}
	?>
	  </div>

    </div>

  </div>
</form>