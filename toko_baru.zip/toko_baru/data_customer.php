<?php
	include 'index.php';
?>



<form style="margin:20px">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
<span class="glyphicon glyphicon-plus"></span> Tambah</button>

<a href="print_data_customer.php" target="_blank" class="btn btn-danger" role="button"> 
<span class="glyphicon glyphicon-print"></span> Print</button>
</a>
</form>

<form style="margin:20px" method="POST" action="">
<div class="table-responsive"> 
<table class="table table-striped table-bordered table-hover">
		<tr>
            <th>Kode Customer</th>
            <th>Nama Customer</th>
			<th>Alamat</th>
			<th>Telepon</th>
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT kode_customer, nama_customer, alamat, telepon FROM tb_data_customer';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_customer']; ?></td>
			<td><?php echo $data['nama_customer']; ?></td>
			<td><?php echo $data['alamat']; ?></td>
			<td><?php echo $data['telepon'];?></td>
		</tr>
	<?php } ?>
</table>
</div>

<!-- Modal Tambah -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Customer</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
                                            <label>Kode Customer</label>
                                            <input class="form-control" required autocomplete="off" name="kode_customer" maxlength="40">
                                        </div>  
										<div class="form-group">
                                            <label>Nama Customer</label>
                                            <input class="form-control" autocomplete="off" name="nama_customer" maxlength="50">
                                        </div>
										<div class="form-group">
                                            <label>Alamat</label>
                                            <input class="form-control" required autocomplete="off" name="alamat" maxlength="40">
																				</div>
																				<div class="form-group">
                                            <label>Kota</label>
                                            <input class="form-control" required autocomplete="off" name="kota" maxlength="40">
																				</div>
										<div class="form-group">
                                            <label>Telepon</label>
                                            <input class="form-control" required autocomplete="off" name="telepon" maxlength="55">
																				</div>
																				<div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" required autocomplete="off" name="email" maxlength="55">
                                        </div>	
																				
                                        <button type="submit" class="btn btn-primary" name="simpan">
										<span class="glyphicon glyphicon-save"></span> Simpan</button>
                                        <button type="reset" class="btn btn-danger" data-dismiss="modal">
										<span class="glyphicon glyphicon-remove"></span> Batal</button>
      <?php
		if (isset($_POST['simpan'])){
			//$modal= $_POST['myModal'];
			$kode_supplier = $_POST['kode_customer'];
			$nama_supplier = $_POST['nama_customer'];
			$alamat = $_POST['alamat'];
			$telepon = $_POST['telepon'];
			$email = $_POST['email'];
			$kota = $_POST['kota'];
			//include_once("koneksi.php");
			mysqli_query($conn, "INSERT INTO tb_data_customer(kode_customer,nama_customer,alamat,telepon) VALUES('$kode_supplier','$nama_supplier','$alamat','$telepon')");
			
		}
	?>
	  </div>

    </div>

  </div>
</div>
</form>