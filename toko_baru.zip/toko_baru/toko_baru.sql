-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2019 at 10:58 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_baru`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_barang`
--

CREATE TABLE `tb_data_barang` (
  `kode_barang` int(10) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `harga_beli` varchar(30) NOT NULL,
  `satuan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_data_barang`
--

INSERT INTO `tb_data_barang` (`kode_barang`, `nama_barang`, `kategori`, `harga_beli`, `satuan`) VALUES
(11545, 'Beras Merah', 'Bahan Makanan', '10000', 'kg'),
(111809, 'Beras Putih', 'Beras', '10000', '25');

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_customer`
--

CREATE TABLE `tb_data_customer` (
  `kode_customer` varchar(10) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `kota` varchar(100) NOT NULL,
  `telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_data_customer`
--

INSERT INTO `tb_data_customer` (`kode_customer`, `nama_customer`, `alamat`, `kota`, `telepon`) VALUES
('UW001', 'Purwo Hadi', 'Blitar', '', '08946513298'),
('UW002', 'Gugus', 'Surabaya', '', '798465231'),
('UW003', 'Bagong Jaya', 'Nganjuk', '', '085735646123');

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_supplier`
--

CREATE TABLE `tb_data_supplier` (
  `kode_supplier` varchar(15) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `telepon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_data_supplier`
--

INSERT INTO `tb_data_supplier` (`kode_supplier`, `nama_supplier`, `alamat`, `telepon`) VALUES
('SUP', 'PT. Maju Terusan', 'Jln. Imam Bonjol - Surabaya', 85733666),
('SUP2', 'Bagus Jaya', 'Malang', 345221),
('SUP2', 'Bagus Jaya', 'Malang', 345221),
('Sop2', 'Jaya', 'Malang', 98754521),
('Sop2', 'Jaya', 'Malang', 98754521),
('sasa', 'dada', 'adad', 0),
('ewewe', 'hgh', 'fgfg', 65464);

-- --------------------------------------------------------

--
-- Table structure for table `tb_laporan_pembelian`
--

CREATE TABLE `tb_laporan_pembelian` (
  `no_faktur` varchar(15) NOT NULL,
  `tanggal` varchar(30) NOT NULL,
  `kode_pembelian` varchar(15) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `harga` varchar(15) NOT NULL,
  `quantity` varchar(15) NOT NULL,
  `total` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_laporan_pembelian`
--

INSERT INTO `tb_laporan_pembelian` (`no_faktur`, `tanggal`, `kode_pembelian`, `nama_supplier`, `harga`, `quantity`, `total`) VALUES
('LKZ001', '6 Desember 2018', 'ASD', 'PT. Maju Terusan', '50000', '15', '750000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_laporan_penjualan`
--

CREATE TABLE `tb_laporan_penjualan` (
  `no_faktur` varchar(15) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `kode_penjualan` varchar(15) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `harga` varchar(15) NOT NULL,
  `quantity` varchar(15) NOT NULL,
  `total` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_laporan_penjualan`
--

INSERT INTO `tb_laporan_penjualan` (`no_faktur`, `tanggal`, `kode_penjualan`, `nama_customer`, `harga`, `quantity`, `total`) VALUES
('INK003', '6 Desember 2018', 'DWS31', 'Purwo Hadi', '12000', '3', '36000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_opname`
--

CREATE TABLE `tb_opname` (
  `no` int(11) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `jumlah` varchar(30) NOT NULL,
  `pilihan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_opname`
--

INSERT INTO `tb_opname` (`no`, `nama_barang`, `jumlah`, `pilihan`) VALUES
(1, 'Beras Putih', '30', 'Masuk'),
(2, 'Beras Putih', '10', 'Keluar'),
(2, 'Beras Putih', '10', 'Keluar');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembayaran_hutang`
--

CREATE TABLE `tb_pembayaran_hutang` (
  `kode_pem_hutang` varchar(10) NOT NULL,
  `tanggal_pembayaran` varchar(30) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `total_bayar` varchar(15) NOT NULL,
  `tunai` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pembayaran_hutang`
--

INSERT INTO `tb_pembayaran_hutang` (`kode_pem_hutang`, `tanggal_pembayaran`, `nama_customer`, `total_bayar`, `tunai`) VALUES
('1', 'desember', 'Purwo Hadi', '100000', '100000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pembelian`
--

CREATE TABLE `tb_pembelian` (
  `kode_pembelian` varchar(10) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `harga_beli` decimal(30,0) NOT NULL,
  `tanggal_pembelian` varchar(30) NOT NULL,
  `quantity` int(15) NOT NULL,
  `satuan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pembelian`
--

INSERT INTO `tb_pembelian` (`kode_pembelian`, `nama_barang`, `nama_supplier`, `harga_beli`, `tanggal_pembelian`, `quantity`, `satuan`) VALUES
('ASD', 'Beras Putih', 'PT. Maju Terusan', '10000', '5 Desember 2018', 15, 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_penjualan`
--

CREATE TABLE `tb_penjualan` (
  `kode_penjualan` varchar(15) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `nama_customer` varchar(30) NOT NULL,
  `harga_jual` varchar(15) NOT NULL,
  `tanggal_penjualan` varchar(15) NOT NULL,
  `quantity` varchar(15) NOT NULL,
  `satuan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_penjualan`
--

INSERT INTO `tb_penjualan` (`kode_penjualan`, `nama_barang`, `nama_customer`, `harga_jual`, `tanggal_penjualan`, `quantity`, `satuan`) VALUES
('DWS1', 'Beras Putih', 'Purwo Hadi', '12000', '6 Desember 2018', '3', 'kg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_data_barang`
--
ALTER TABLE `tb_data_barang`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indexes for table `tb_data_customer`
--
ALTER TABLE `tb_data_customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `tb_pembayaran_hutang`
--
ALTER TABLE `tb_pembayaran_hutang`
  ADD PRIMARY KEY (`kode_pem_hutang`);

--
-- Indexes for table `tb_pembelian`
--
ALTER TABLE `tb_pembelian`
  ADD PRIMARY KEY (`kode_pembelian`);

--
-- Indexes for table `tb_penjualan`
--
ALTER TABLE `tb_penjualan`
  ADD PRIMARY KEY (`kode_penjualan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
