<html>
<head>
<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Print Data Customer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<form style="margin:20px">
<div class="table-responsive"> 
<table class="table table-striped table-bordered table-hover">
		<tr>
            <th>Nama</th>
            <th>Kode</th>
			<th>Harga</th>
			<th>Satuan</th>
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT kode_customer, nama_customer, alamat, telepon FROM tb_data_customer';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_customer']; ?></td>
			<td><?php echo $data['nama_customer']; ?></td>
			<td><?php echo $data['alamat']; ?></td>
			<td><?php echo $data['telepon'];?></td>
		</tr>
	<?php } ?>
</table>
</div>
<script> window.print(); </script>
</form>
</body>
</html>