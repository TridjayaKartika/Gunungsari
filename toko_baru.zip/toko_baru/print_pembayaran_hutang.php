<html>
<head>
<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Print Pembayaran Hutang</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<form style="margin:20px">
<div class="table-responsive"> 
<table class="table table-striped table-bordered table-hover">
		<tr>
            <th>No Nota</th>
            <th>Tanggal</th>
			<th>Customer</th>
			<th>Total Harga</th>
            <th>Total Bayar</th>
            <th>Kurang</th>
		<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT * FROM tb_pembayaran_hutang';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_pem_hutang']; ?></td>
			<td><?php echo $data['tanggal_pembayaran']; ?></td>
			<td><?php echo $data['nama_customer']; ?></td>
			<td><?php echo $data['total_bayar'];?></td>
			<td><?php echo $data['tunai'];?></td>
			<td><?php echo $data['kembali'];?></td>
			
		</tr>
	<?php } ?>
	</tr>
</table>
</div>
<script> window.print(); </script>
</form>
</body>
</html>