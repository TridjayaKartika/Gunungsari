<?php

	$db_host = 'localhost'; // Nama Server
	$db_user = 'root'; // User Server
	$db_pass = ''; // Password Server
	$db_name = 'toko_baru'; // Nama Database
	
	$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
?>