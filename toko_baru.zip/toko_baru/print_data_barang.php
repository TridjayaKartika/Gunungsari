<html>
<head>
<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Print Data Barang</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<form style="margin:20px">
<div class="table-responsive"> 
<table class="table table-striped table-bordered table-hover">
		<tr>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
			<th>Kategori</th>
			<th>Harga Beli</th>
			<th>Satuan</th>
	</tr>
	<?php
	include "koneksi.php";
		
	
	if (!$conn) {
		die ('Gagal terhubung MySQL: ' . mysqli_connect_error());	
	}
	$sql = 'SELECT kode_barang, nama_barang, kategori, harga_beli, satuan FROM tb_data_barang';
	$query = mysqli_query($conn, $sql);
	if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
	while($data = mysqli_fetch_array($query)){
		?>
		<tr>
			
			<td><?php echo $data['kode_barang']; ?></td>
			<td><?php echo $data['nama_barang']; ?></td>
			<td><?php echo $data['kategori']; ?></td>
			<td><?php echo "Rp. ";echo $data['harga_beli']; ?></td>
			<td><?php echo $data['satuan']; echo" kg"?></td>
		</tr>
	<?php } ?>
</table>
</div>
<script> window.print(); </script>
</form>
</body>
</html>