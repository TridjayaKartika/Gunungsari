<?php
	include 'index.php';
?>

<form style="margin:20px">
<table border="1" class="table table-striped table-bordered table-hover">
  <tr>
    <td width="40%">Kode</td>
    <td width="60%">: </td>
  </tr>
  <tr>
    <td>Nama</td>
    <td>: </td>
  </tr>
  <tr>
    <td>Satuan</td>
    <td>: </td>
  </tr>
  <tr>
    <td>Tanggal Cetak</td>
    <td>: <?php echo $tanggal = date("d/m/Y"); ?></td>
  </tr>
</table>
<a  href ="cetak_laporan_stok.php" target="_blank" class="btn btn-primary" role="button">
<span class="glyphicon glyphicon-print"></span> Print Laporan 
</a>

<table class='table table-striped table-bordered table-hover'>
		<tr>
            <th width="12%">No</th>            
            <th width="12%">Tanggal</th>                      
            <th width="12%">No Bukti</th>
            <th width="12%">Masuk</th>
            <th width="12%">Keluar</th>
			<th width="12%">Stok</th>
            <th width="28%">Keterangan</th>
	</tr>
	</table>
</form>