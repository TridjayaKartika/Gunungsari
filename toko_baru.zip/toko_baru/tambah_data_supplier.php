<html>
<head>
    <title>Add Users</title>
</head>

<body>
    <a href="index.php">Go to Home</a>
    <br/><br/>

    <form action="data_supplier.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>Kode Supplier</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr> 
                <td>Nama Supplier</td>
                <td><input type="text" name="email"></td>
            </tr>
            <tr> 
                <td>Alamat</td>
                <td><input type="text" name="mobile"></td>
            </tr>
			<tr> 
                <td>Telepon</td>
                <td><input type="text" name="mobile1"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
			
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $mobile = $_POST['mobile'];
		$mobile1 = $_POST['mobile1'];
        // include database connection file
        include_once("koneksi.php");

        // Insert user data into table
        $result = mysql_query($conn, "INSERT INTO tb_data_supplier(name,email,mobile,mobile1) VALUES('$name','$email','$mobile','$mobile1')");

        // Show message when user added
        echo "User added successfully. <a href='data_supplier.php'>View Users</a>";
    }
    ?>
</body>
</html>